package com.cg.ams.automate.initialization;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;
/**
 * 
 * @author shmukka
 *
 */
public class InitConfiguration {
	//initializing logger
	private static final Logger LOGGER = Logger.getLogger(InitLogger.class.getName());
	//method for loading config properties
	public Properties loadConf(){
		Properties prop = null;
		try {
    		InputStream inputStream = Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("config.properties");
			prop = new Properties();		
			prop.load(inputStream);				
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
			LOGGER.info(e.toString());
		} 
		catch (IOException e) {
			e.printStackTrace();
			LOGGER.info(e.toString());
		}
		return prop;  
	}
}
