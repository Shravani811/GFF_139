package com.cg.ams.automate.email;

import java.io.FileNotFoundException;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.cg.ams.automate.initialization.InitLogger;
/**
 * 
 * @author shmukka
 *
 */

public class SendEmail 
{
	String result;
	Properties prop;
	//initializing logger
	private static final Logger LOGGER = Logger.getLogger(InitLogger.class.getName());
	//method for sending email to relevant receipients
	public SendEmail() 
	{
		try {
			InputStream inputStream = Thread.currentThread().getContextClassLoader()
					.getResourceAsStream("logging.properties");
			LogManager.getLogManager().readConfiguration(inputStream);
			LOGGER.info("Initializing logger");
		} catch (Exception e) {
			LOGGER.severe("Error Message :" + e.getMessage());
			e.printStackTrace();
		}
	}
	
	 public String sendMail(String filepath , String fileName, String mailmsg) throws IOException	 
	 {  
		 try 
			{
				InputStream inputStream = Thread.currentThread().getContextClassLoader()
	                    .getResourceAsStream("config.properties");
				prop = new Properties();		
				prop.load(inputStream);				
			} 
		 catch (FileNotFoundException e) 
			{
				e.printStackTrace();
				LOGGER.info(e.toString());
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
				LOGGER.info(e.toString());
			}  
			
		 String to=prop.getProperty("receiver");
		 
		 final String user=prop.getProperty("sender");  
		 final String password=prop.getProperty("mailpwd");
		 String subject = prop.getProperty("subject");
		 subject = subject+" "+java.time.LocalDate.now();
	//	 String msg = prop.getProperty("message");
		 String host = prop.getProperty("host");
		 String port = prop.getProperty("port");
		 
		 
	   
	  //1) get the session object     
		 Properties props = System.getProperties();  
		 props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.host", host );  
	        props.put("mail.smtp.port", port);
	  
		 Session session = Session.getDefaultInstance(props,  
				 new javax.mail.Authenticator() {  
	   protected PasswordAuthentication getPasswordAuthentication() {  
	   return new PasswordAuthentication(user,password);  
	   }  
	  });  
	     
	  //2) compose message     
	  try{  
	    MimeMessage message = new MimeMessage(session);  
	    message.setFrom(new InternetAddress(user));  
	    message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
	    message.setSubject(subject);  
	      
	    //3) create MimeBodyPart object and set your message text     
	    BodyPart messageBodyPart1 = new MimeBodyPart();  
	    
	    messageBodyPart1.setContent(mailmsg, "text/html");
	    
	      
	    //4) create new MimeBodyPart object and set DataHandler object to this object      
	    MimeBodyPart messageBodyPart2 = new MimeBodyPart();  
	  
	    DataSource source = new FileDataSource(filepath+fileName); 
		messageBodyPart2.setDataHandler(new DataHandler(source));  
		messageBodyPart2.setFileName(java.time.LocalDate.now()+"_"+fileName);  
		     
	   
	     
	    //5) create Multipart object and add MimeBodyPart objects to this object      
	    Multipart multipart = new MimeMultipart();  
	    multipart.addBodyPart(messageBodyPart1);  
	    multipart.addBodyPart(messageBodyPart2);  
	  
	    //6) set the multipart object to the message object  
	    try
	    {
	    	message.setContent(multipart);  
	    }
	    catch(MessagingException e)
	    {
	    	result = e.toString();
	    }
	    catch(Exception e)
	    {
	    	result = e.toString();
	    }
	    //7) send message  
	    Transport.send(message);  
	    result = "sent successfully";	  
	  }
	  catch (MessagingException ex) 
	  {
		  ex.printStackTrace();
		  result = ex.toString();
		  LOGGER.info(result);
	  }
	  catch (Exception ex) 
	  {
		  ex.printStackTrace();
		  result = ex.toString();
		  LOGGER.info(result);
	  }
	  
	  
	return result;  
	 }  
	}  
