/*
 * http://www.apache.org/licenses/LICENSE-2.0
 */

package com.cg.ams.automate.main;

import java.io.BufferedReader;



import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.net.ssl.HttpsURLConnection;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;

import com.cg.ams.automate.connection.SNOWConnection;
import com.cg.ams.automate.email.SendEmail;
import com.cg.ams.automate.initialization.InitConfiguration;
import com.cg.ams.automate.initialization.InitLogger;

/**
 * 
 * @author shmukka
 *
 */
//main class 
public class SimpleService {
	//creating properties object
	static Properties prop;
 //main method
    public static void main(String[] args) throws FileNotFoundException, IOException {
    	//loading log properties file
    	final Logger logger = Logger.getLogger(InitLogger.class.getName());
    	
    	//loading configuration properties
    	final InitConfiguration conf = new InitConfiguration();
		prop = conf.loadConf();  
		
    	HashMap<String, Integer> hMap = new HashMap<String, Integer>();
    	final OutputStream outputStream;
    	String resp = "";
    	
		// fetching Username and password of Service Now QA from conf
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		try{
		  //service now QA URL with filteration of incidents based on yesterday's date	     
		 String url = prop.getProperty("snowurl");				 
		 
		 SNOWConnection conn = new SNOWConnection(); 
		 final HttpsURLConnection httpconn = conn.snowconn(username, password, url);
	    
		 StringBuffer response;
		//getting the response code  
	      int responseGet = httpconn.getResponseCode();
	      logger.info("connected"+responseGet);     
	      logger.info("GET Response Code for getting sysid:: " + responseGet);
	      if (responseGet == 200 || responseGet == 201) { 
	    	  // success connection
	          BufferedReader in = new BufferedReader(new InputStreamReader(httpconn.getInputStream()));
	          response = new StringBuffer();
	          String inputLine; 
	          while ((inputLine = in.readLine()) != null) {
	              response.append(inputLine);
	              logger.info("response======="+response.toString());
	          }
	          in.close();
	          httpconn.disconnect();
	      
		      JSONObject item;	 
		      final JSONObject jsnobject = new JSONObject(response.toString());	      
		      final JSONArray jsonArray = jsnobject.getJSONArray("result");
		      //for block is for testing
		      for (int i = 0; i < jsonArray.length(); i++) {
		    	  item = jsonArray.getJSONObject(i);	          
		      }
	     
		      String res;
		      //creating workbook
		      XSSFWorkbook workbook = new XSSFWorkbook();
		      //creating sheet naming "Report" inside workbook 
			  XSSFSheet sheet = workbook.createSheet("Report");
			  int rowCount = 0;
			  
			  Object number;
			  Object shDesc;
			  Object desc;
			  Object subcategory;
			  //creating rows based on incidents from service now
			  Row header = sheet.createRow(0);
			  header.createCell(0).setCellValue("number");
			  header.createCell(1).setCellValue("description");
			  header.createCell(2).setCellValue("short_description");
			  header.createCell(3).setCellValue("subcategory");
			  //iterating on the value of incidents and adding it into the excel
		      for (int i = 0; i < jsonArray.length(); i++){
		    	  Integer count = 1;
		    	  item = jsonArray.getJSONObject(i);
				  number = item.get("number");
				  desc = item.get("description");
				  shDesc = item.get("short_description");
				  subcategory = item.get("subcategory");   
				  
				  if(!subcategory.equals("")) {
					  if(!hMap.containsKey((String) item.get("subcategory"))) {
						  hMap.put((String) item.get("subcategory"), count);
					  }else if(hMap.containsKey((String) item.get("subcategory"))){
						  hMap.put((String) item.get("subcategory"), hMap.get((String) item.get("subcategory"))+1);
					  }
				  }
				  				 				 
				  Row row = sheet.createRow(++rowCount);            
				  Cell cell1 = row.createCell(0);
				  cell1.setCellValue(number.toString());
				  Cell cell2 = row.createCell(1);
				  cell2.setCellValue(desc.toString());
				  Cell cell3 = row.createCell(2);  
				  cell3.setCellValue(shDesc.toString());
				  Cell cell4 = row.createCell(3);
				  cell4.setCellValue(subcategory.toString());  					
		     }
		     
		      		       
		      Map<String, Integer> sortedMapInDescending = hMap.entrySet()
		  			.stream()
		  			.sorted(Collections.reverseOrder(Entry.comparingByValue()))
		  			.collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue(),
		  					(entry1, entry2) -> entry2, LinkedHashMap::new));
		    
			try {
				//giving the path of the excel for writing the incidents
				final String filePath=prop.getProperty("filepath");
				logger.info("FilePath :"+filePath);		
				final String fileName=prop.getProperty("filename");
				logger.info("FileName :"+fileName);
				logger.info("total path"+filePath+fileName);
				outputStream = Files.newOutputStream(Paths.get(filePath+fileName));
				workbook.write(outputStream);
				res="Excel report created";	
				logger.info(res);
				outputStream.close();
				String text=  
				         "<table width='100%' border='1' align='center'>\n"
				                + "<tr align='center'>\n"
				                + "<td><b>SubCategory <b></td>\n"
				                + "<td><b>Ticket Count<b></td>\n"
				                + "</tr>\n";
 
				for (Map.Entry entry : sortedMapInDescending.entrySet()) {
				                    text=text+"<tr align='center'>\n"+
				                    "<td>\n" + entry.getKey() + "</td>\n"
				                                + "<td>\n" + entry.getValue() + "</td>\n"+"</tr>\n";
				}			
				StringBuilder buf = new StringBuilder();
				String msg = prop.getProperty("message");
				buf.append("Hi,");
				buf.append("<br>");
				buf.append(msg);
				buf.append(text);
				buf.append("</table>\n");
				buf.append("<br>");
				String thanksmsg = prop.getProperty("thanksmsg");
				buf.append(thanksmsg);
				buf.append("<br>");
				String team = prop.getProperty("team");
				buf.append(team);
				String mailmsg = buf.toString();
				SendEmail mail = new SendEmail();
				res=text+res+mail.sendMail(filePath,fileName,mailmsg); 
				logger.info(res);
				} 
				catch (Exception e) {
					res=e.toString();        
					logger.info(res);
				}
	      }
    }  
    catch (MalformedURLException error) {
        // Output expected MalformedURLExceptions.
        resp = "Invalid request.Check the parameters";      
        logger.info(resp+error.toString());
    } catch (Exception exception) {
        // Output unexpected Exceptions.
        resp = "Invalid request.Check the parameters";
        logger.info(resp+exception.toString());
    }  	
  }
}
