package com.cg.ams.automate.connection;

import java.io.IOException;
import java.net.URL;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;

import com.cg.ams.automate.initialization.InitLogger;
/**
 * 
 * @author shmukka
 *
 */
public class SNOWConnection {
	//initializing logger
	private static final Logger LOGGER = Logger.getLogger(InitLogger.class.getName());//init
	// method for service now connection
	public HttpsURLConnection snowconn(String username, String password,String url){
		HttpsURLConnection conn = null;
		int responseGet = 0;
		try {
			URL obj = new URL(url);
			conn = (HttpsURLConnection) obj.openConnection();
			conn.setRequestMethod("GET");       
		      String authString = username + ":" + password;
		      LOGGER.info("auth string:" + authString);	
		     
		      String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authString.getBytes());
		      conn.setRequestProperty("Authorization", basicAuth);
		      conn.setRequestProperty("Content-Type", "application/json");
		      conn.setDoOutput(true);
		      
		      
		} catch (IOException e) {
			LOGGER.info(e.toString());
			e.printStackTrace();
		}
		return conn;        
	}
}
