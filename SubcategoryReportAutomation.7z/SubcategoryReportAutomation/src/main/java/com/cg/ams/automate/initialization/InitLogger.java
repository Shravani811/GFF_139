package com.cg.ams.automate.initialization;

import java.io.InputStream;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;
/**
 * 
 * @author shmukka
 *
 */
public class InitLogger {
	
	//method for loading logging properties
	void loadlogs(){
		final Logger logger = Logger.getLogger(InitLogger.class.getName());
	
	try {
		InputStream inputStream = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("logging.properties");
		LogManager.getLogManager().readConfiguration(inputStream);
		logger.info("Initializing logger");
	}catch(Exception e) {
		logger.severe("Error Message :" + e.getMessage());
		e.printStackTrace();
	}
	}
	
}
