package com.cg.ams.automate.fetch;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;


@XmlRootElement(name ="response")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class IncidentElement {
	List<Result> result;

	 
	public List<Result> getResult() {
		return result;
	}

	public void setResult(List<Result> result) {
		this.result = result;
	}

	public IncidentElement(List<Result> result) {
		super();
		this.result = result;
	}

	public IncidentElement() {
		super();
		// TODO Auto-generated constructor stub
	}

//	@Override
//	public String toString() {
//		return "IncidentElement [result=" + result + "]";
//	}
//	
	
}
