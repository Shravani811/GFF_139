package com.cg.ams.automate.fetch;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name ="result")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Result {
	String number;
	String state;
	String sysCreatedOn;
    String short_description;
    
    @XmlElement(name="number")
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	@XmlElement(name="state")
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	@XmlElement(name="sysCreatedOn")
	public String getSysCreatedOn() {
		return sysCreatedOn;
	}
	public void setSysCreatedOn(String sysCreatedOn) {
		this.sysCreatedOn = sysCreatedOn;
	}
	
	@XmlElement(name="short_description")
	public String getShort_description() {
		return short_description;
	}
	public void setShort_description(String short_description) {
		this.short_description = short_description;
	}
	public Result(String number, String state, String sysCreatedOn, String short_description) {
		super();
		this.number = number;
		this.state = state;
		this.sysCreatedOn = sysCreatedOn;
		this.short_description = short_description;
	}
	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}
    
  
 

	
}  

