package com.cg.ams.automate.initialization;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

public class InitConfiguration {
	//initializing logger
		static Logger logger = Logger.getLogger(InitLogger.class.getName());
		//method for loading config properties
		public Properties loadConf(){
			Properties prop = null;
			try {
	    		InputStream inputStream = Thread.currentThread().getContextClassLoader()
	                    .getResourceAsStream("config.properties");
				prop = new Properties();		
				prop.load(inputStream);				
			} 
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(e.toString());
			} 
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(e.toString());
			}
			return prop;  
		}
}
