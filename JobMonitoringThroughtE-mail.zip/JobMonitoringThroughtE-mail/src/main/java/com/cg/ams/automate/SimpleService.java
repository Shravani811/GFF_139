package com.cg.ams.automate;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

import com.cg.ams.automate.connection.ConnectToMail;
import com.cg.ams.automate.initialization.InitConfiguration;
import com.cg.ams.automate.initialization.InitLogger;

public class SimpleService {

	static Properties prop;
	static String user;
	static String password;
	static String host;
	static String port;
	static String storeType;
	static String configFile = "D:\\Users\\sasanap\\Documents\\workspace-spring-tool-suite-4-4.15.1.RELEASE\\JobMonitoringThroughtE-mail\\src\\main\\resource\\config.properties";
	static String excelFile;

    public static void main(String[] args) throws Exception {
    	//loading log properties file
    	Logger logger = Logger.getLogger(InitLogger.class.getName());
    	
    	//loading configuration properties
    	InitConfiguration conf = new InitConfiguration();
		prop = conf.loadConf();  
		
		String password=prop.getProperty("password1");
		System.out.println(password);
		user = prop.getProperty("username");
		System.out.println(user);
		password = prop.getProperty("password");
		//cSystem.out.println(password);
		host = prop.getProperty("host");
		System.out.println(host);
		port = prop.getProperty("port");
		storeType = prop.getProperty("storeType");
		System.out.println(storeType);
		
		ConnectToMail connect= new ConnectToMail();
		connect.connectionToEmail(user, password, port, host);
    }
}
