package com.cg.ams.automate.validate;

import java.io.IOException;

import javax.mail.Message;
import javax.mail.MessagingException;

import com.cg.ams.automate.email.ReadMailBody;
import com.cg.ams.automate.fetch.FetchIncident;
import com.cg.ams.automate.updation.UpdateFinalTable;


/**
 *
 *
 * @author Sangram
 */
public class CheckSubjectLine {

	CheckContry cc = new CheckContry();
	UpdateFinalTable uft = new UpdateFinalTable();
	ReadMailBody rmb = new ReadMailBody();
	int rowIndex;
	static int columnNumber;
    //for checking Subject
	public void checkMailSubject(String subject, Message message) throws Exception {
		String sub = subject;
		FetchIncident fetchIncident= new  FetchIncident();
		String number=null;
		if (sub.contains("STAG")) {
			if (sub.contains("REPORTING")) {
				rowIndex = cc.checkCountryCode(sub);
				System.out.println(rowIndex);

				if (sub.contains("OK")) {
					columnNumber = 2;
					for (int i = 2; i <= 5; i++) {
						uft.finalTableUpdation(rowIndex, columnNumber,number);
						columnNumber++;
					}

				} else if (sub.contains("ALERT")) {
					rmb.getTextFromMessage(message);
					fetchIncident.checkUnresolvedIncident(subject);
				

				}

			} else if (sub.contains("OPERATIONAL")) {
				rowIndex = cc.checkCountryCode(sub);
				System.out.println(rowIndex);

				if (sub.contains("OK")) {
					columnNumber = 2;
					for (int i = 2; i <= 5; i++) {
						uft.finalTableUpdation(rowIndex, columnNumber,number);
						columnNumber++;
					}
				} else if (sub.contains("ALERT")) {
					cc.checkCountryCode(sub);
				}
			}

		} else if (sub.contains("PROD")) {
			if (sub.contains("REPORTING")) {
				rowIndex = cc.checkCountryCode(sub);
				System.out.println(rowIndex);

				if (sub.contains("OK")) {
					columnNumber = 6;
					for (int i = 2; i <= 5; i++) {
						uft.finalTableUpdation(rowIndex, columnNumber,number);
						columnNumber++;
					}
				} else if (sub.contains("ALERT")) {

					
				}

			} else if (sub.contains("OPERATIONAL")) {
				rowIndex = cc.checkCountryCode(sub);
				System.out.println(rowIndex);

				if (sub.contains("OK")) {
					columnNumber = 6;
					for (int i = 2; i <= 5; i++) {
						uft.finalTableUpdation(rowIndex, columnNumber,number);
						columnNumber++;
					}

				} else if (sub.contains("ALERT")) {
//					ReadMailBody1 rmb1=new ReadMailBody1();
//					rmb1.writePart(message);
					String result=rmb.getTextFromMessage(message);
					if(result.equalsIgnoreCase("Alert"));{
						System.out.println("Alert");
						//System.out.println(result);
						 number=fetchIncident.checkUnresolvedIncident(subject);
						uft.finalTableUpdation(rowIndex, 9,number);
					}
					

				}

			}

		}

	}
}
