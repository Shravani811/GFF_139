package com.cg.ams.automate.connection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Properties;
import java.util.logging.Logger;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;

import com.cg.ams.automate.initialization.InitLogger;
import com.cg.ams.automate.validate.CheckSubjectLine;
import com.sun.mail.util.MailSSLSocketFactory;

/**
 *
 *
 * @author Sangram
 */
public class ConnectToMail {

	static Logger logger = Logger.getLogger(ConnectToMail.class.getName());
	static Properties props = new Properties();
    //for connect to mail
	public void connectionToEmail(String user,String password,String port,String host ) throws Exception {

		MailSSLSocketFactory sf = null;
		Folder inbox = null;
		Store store = null;
		try {
			sf = new MailSSLSocketFactory();
			sf.setTrustAllHosts(true);

		} catch (GeneralSecurityException e11) {
			// TODO Auto-generated catch block
			logger.severe("Error: " + e11.getMessage());
		}

		System.out.println(user + "-----------" + password);
		props.put("mail.imap.ssl.trust", "*");
		props.put("mail.imap.ssl.socketFactory", sf);
		props.setProperty("mail.imap.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.setProperty("mail.imap.socketFactory.fallback", "false");
		props.setProperty("mail.imap.port", port);
		props.setProperty("mail.imap.socketFactory.port", port);
		props.put("mail.imap.host", host);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, password);

			}
		});

		try {
			store = session.getStore("imap");
			store.connect(host, user, password);

			System.out.println("complete");
			logger.info("store connect");
			logger.info("Logged in to the mail box");

			// Getting mailbox mails.
			Folder inbox1 = store.getFolder("INBOX");
			inbox1.open(Folder.READ_WRITE);
			System.out.println(inbox1);
			int totalMailCount = inbox1.getMessageCount();

			// create the folder object and open it
//			      Folder emailFolder = store.getFolder("INBOX");
//			      emailFolder.open(Folder.READ_ONLY);

			// retrieve the messages from the folder in an array and print it
			Message[] messages = inbox1.getMessages();
			System.out.println("messages.length---" + messages.length);

			for (int i = 0, n = messages.length; i < n; i++) {
				Message message = messages[i];
				System.out.println("---------------------------------");
				System.out.println("Email Number " + (i + 1));
				String subject = message.getSubject();
				System.out.println("Subject: " + message.getSubject());
				System.out.println("From: " + message.getFrom()[0]);
				System.out.println("Text: " + message.getContent().toString());
//			         ReadMailBody rmb = new ReadMailBody();
//			         String body=rmb.getTextFromMessage(message);
//			         System.out.println(body);
				CheckSubjectLine csl = new CheckSubjectLine();
				csl.checkMailSubject(subject, message);
			}

			// close the store and folder objects

			inbox1.close(true);
			store.close();
		} catch (NoSuchProviderException e1) {
			// TODO Auto-generated catch block
			logger.severe("ERROR: " + e1.getMessage());
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			logger.severe("failed to connect, Invalid IMAP credentails!! \n" + e.getMessage());

		}

	}

}
