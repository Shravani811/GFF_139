package com.cg.ams.automate.validate;

import java.io.IOException;

import com.cg.ams.automate.updation.UpdateFinalTable;

/**
 *
 *
 * @author Sangram
 */
public class CheckContry {
	static UpdateFinalTable uft = new UpdateFinalTable();
	static int rowIndex;
    //for checking country
	public  int checkCountryCode(String sub) throws IOException {
		if (sub.contains("@ID")) {
			System.out.println("@ID");
			rowIndex=3;
		}
		if (sub.contains("@JP")) {
			System.out.println("@JP");
			rowIndex=4;

		}
		if (sub.contains("@AWS KR")) {
			System.out.println("@AWS KR");
			rowIndex=5;
		}
		if (sub.contains("@MY")) {
			System.out.println("@MY");
			rowIndex=6;
		}
		if (sub.contains("@SG")) {
			System.out.println("@SG");
			rowIndex=7;
		}
		if (sub.contains("@TW")) {
			System.out.println("@TW");
			rowIndex=8;
        } 
		if (sub.contains("@VN")) {
			System.out.println("@VN");
			rowIndex=9;
		} 
		if (sub.contains("@UAE")) {
			System.out.println("@UAE");
			rowIndex=10;
		} 
		if (sub.contains("@Bahrain")) {
			System.out.println("@Bahrain");
			rowIndex=11;
		} 
		if (sub.contains("@Cyprus")) {
			System.out.println("@ID");
			rowIndex=12;
		} 
		if (sub.contains("@EG")) {
			System.out.println("@EG");
			rowIndex=13;
		} 
		if (sub.contains("@Delhi")) {
		  System.out.println("@Delhi");
		  rowIndex=14;
		} 
		if (sub.contains("@JO")) {
			System.out.println("@JO");
			rowIndex=15;
		} 
		if (sub.contains("@KW")) {
			System.out.println("@KW");
			rowIndex=16;
		} 
		if (sub.contains("@PK")) {
			System.out.println("@PK");
			rowIndex=17;
		} 
		if (sub.contains("@QA")) {
			System.out.println("@QA");
			rowIndex=18;
		} 
		if (sub.contains("@Riyadh")) {
			System.out.println("@Riyadh");
			rowIndex=19;
		} 
		if (sub.contains("@LK")) {
			System.out.println("@LK");
			rowIndex=20;
		} 
		if (sub.contains("@South Africa")) {
			System.out.println("@South Africa");
			rowIndex=21;
		}
		return rowIndex;

	}
}
