package com.cg.ams.automate.updation;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;

import com.cg.ams.automate.fetch.FetchIncident;



public class UpdateIncident {
	public static final Logger logger = Logger.getLogger(UpdateIncident.class.getName());
	static Properties prop = new Properties();
	FetchIncident fetchIncident = new FetchIncident();
	static String inputLine;
	static String output;
	static String configFile = "D:\\Users\\sasanap\\Documents\\workspace-spring-tool-suite-4-4.15.1.RELEASE\\JobMonitoringThroughtE-mail\\src\\main\\resource\\config.properties";
    static String number1;
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public static void updateUnresolvedIncident(String subject,String number) throws Exception {

		InputStream inputStream;
		String url;
		String username;
		String password;
       String   number1=number;
		try {
			final FileReader fReader = new FileReader(configFile);
			prop.load(fReader);
			fReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("FileNotFoundException");
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("IOExceptionS");
		}
		username = prop.getProperty("username1");
		System.out.println(username);
		password = prop.getProperty("password1");
		url = prop.getProperty("snowurl");
		System.out.println(url);
//		String inc_number=fetchIncident.number;
//		String shortDescription=fetchIncident.short_description;

		URL obj = new URL(url + "/api/now/table/incident?number="+number+"&sysparm_fields=sys_id");
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		String authString = username + ":" + password;
		System.out.println("auth string: " + authString);
		logger.info("auth string: " + authString);
		String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authString.getBytes());
		con.setRequestProperty("Authorization", basicAuth);
		System.out.println(basicAuth);

		int responseCode = con.getResponseCode();
		System.out.println("response code :" + responseCode);

		StringBuffer response = null;
		String resp = null;
		if (responseCode == 200) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}

			System.out.println(response.toString());
			logger.info("incident_get_response :" + response.toString());

			if (response.toString().contains("sys_id")) {
				int index = response.toString().indexOf("sys_id");
				String sysId = response.toString().substring(index + 9, index + 41);
				resp = update(url, basicAuth, sysId, subject);
				System.out.println("Incident "+number+"Updated successfully");
			} else {
				resp = "Incident "+number+" not found";
				System.out.println(resp);

			}
		}
//        HashMap<String, String> hash_map = new HashMap<String, String>();
//        hash_map.put("catalogId", catalog_id);
//        hash_map.put("response", resp);
//        Gson gson = new Gson();
//        String output1 = gson.toJson(hash_map);
//        return output1;

	}

	private static String update(String url, String basicAuth, String sysId, String description) throws IOException {
		URL obj1 = new URL(url + "/api/now/table/incident/" + sysId);
		HttpsURLConnection conn = (HttpsURLConnection) obj1.openConnection();
		conn.setRequestMethod("PUT");
		conn.setRequestProperty("Authorization", basicAuth);
		conn.setDoOutput(true);

		DataOutputStream out = new DataOutputStream(conn.getOutputStream());
		out.write(getOutBytes(description));

		StringBuffer response1 = null;
		int responseCode1 = conn.getResponseCode();
		System.out.println("PUT Response Code for Incident Update:: " + responseCode1);
		logger.info("PUT Response Code for Incident Update:: " + responseCode1);
		String resp1 = null;
		if (responseCode1 == 200) { // success
			BufferedReader bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine1;
			response1 = new StringBuffer();

			while ((inputLine1 = bin.readLine()) != null) {
				System.out.println(response1 + "response1");
				response1.append(inputLine1);
				
			}

			resp1 = response1.toString();
			logger.info(resp1);
			System.out.println(resp1);
			bin.close();
			out.flush();
			out.close();
			conn.disconnect();

		} else {
			resp1 = "failed to update incidents";
			System.out.println(resp1);

		}

		return resp1;

	}

	private static byte[] getOutBytes(String description) {
		JSONObject jsonObj1 = new JSONObject();

		try {
			jsonObj1.put("description",description);
			jsonObj1.put("short_description", description);
		} catch (Exception e) {
			if (e != null) {
				System.out.println("Json Exception Occured" + e.getMessage());
				logger.severe("Json Exception :" + e.getMessage());
			}
		}
		byte[] out = jsonObj1.toString().getBytes(StandardCharsets.UTF_8);
		return out;
	}
}
