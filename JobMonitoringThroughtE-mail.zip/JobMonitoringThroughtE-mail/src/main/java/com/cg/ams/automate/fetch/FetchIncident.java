package com.cg.ams.automate.fetch;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.List;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.cg.ams.automate.initialization.InitLogger;
import com.cg.ams.automate.updation.UpdateIncident;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class FetchIncident {

	/**
	 *
	 *
	 * prop
	 */
	static Properties prop = new Properties();
	static String output;
	static String configFile = "D:\\Users\\sasanap\\Documents\\workspace-spring-tool-suite-4-4.15.1.RELEASE\\JobMonitoringThroughtE-mail\\src\\main\\resource\\config.properties";
	static String filepath;
	static String excelFile;
	public static String number=null;
	public static String shortDescription=null;
	static Logger logger = Logger.getLogger(FetchIncident.class.getName());

	public static String checkUnresolvedIncident(String subject) {

		String url;
		String username;
		String password;

		try {
			final FileReader fReader = new FileReader(configFile);
			prop.load(fReader);
			fReader.close();

			try {
				FileHandler fh = new FileHandler(prop.getProperty("path"));
				System.out.println(fh);
				logger.addHandler(fh);
				SimpleFormatter formatter = new SimpleFormatter();
				fh.setFormatter(formatter);
				fh.close();
			} catch (Exception e) {
				logger.severe("ERROR : " + e.getMessage());
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("FileNotFoundException");
			logger.info("Config file not found ,please check file path..");
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("IOExceptionS");
		}

		url = prop.getProperty("snowurl1");
		username = prop.getProperty("username1");
		System.out.println(username);
		password = prop.getProperty("password1");
		System.out.println(password);
		filepath = prop.getProperty("filepath");
		excelFile = prop.getProperty("excelFile");

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();

		// url = url.replaceAll(" ","%20");
		try {

			Client client = Client.create();
			WebResource webResource = client.resource(url);

			client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(username, password));

			ClientResponse response = webResource.accept("application/xml").get(ClientResponse.class);

			if (response.getStatus() != 200) {
				output = "Request Processing Failed : HTTP error code : " + response.getStatus();
				logger.info("Request Processing Failed : HTTP error code:" + response.getStatus());

			} else {
				output = response.getEntity(String.class);

			}
			JAXBContext jaxbContext;
			try {

				jaxbContext = JAXBContext.newInstance(IncidentElement.class);

				// Now get the Unmarshaller instance from JAXBContext
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				// System.out.println(jaxbUnmarshaller);

				// unmarshal() method unmarshal XML data from the specified XML
				IncidentElement incidentElement = (IncidentElement) jaxbUnmarshaller.unmarshal(new StringReader(output));
                
				List<Result> list = incidentElement.getResult();

				if (list == null) {
					
					System.out.println("There is no any incident which is following our charteria");
					logger.info("There is no any incident which is follow our charteria");
				} else {
					
					for (Result result : list) {

						number = result.getNumber();
						System.out.println(number);
						String state = result.getState();
						System.out.println(state);
						shortDescription=result.getShort_description();
						System.out.println(shortDescription);
						if(shortDescription.contains(subject)){
							UpdateIncident updateIncident= new UpdateIncident();
							updateIncident.updateUnresolvedIncident(subject,number);
							
						}

					}
				}

			} catch (JAXBException e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return number;

	}
}
