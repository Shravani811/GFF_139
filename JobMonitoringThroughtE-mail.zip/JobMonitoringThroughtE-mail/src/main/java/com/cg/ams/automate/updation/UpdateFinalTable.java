package com.cg.ams.automate.updation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UpdateFinalTable {
	/**
	*
	*
	* prop
	*/
	static Properties prop = new Properties();
	static String configFile = "D:\\Users\\sasanap\\Documents\\workspace-spring-tool-suite-4-4.15.1.RELEASE\\JobMonitoringThroughtE-mail\\src\\main\\resource\\config.properties";
	static String excelPath;
	public static void finalTableUpdation(int row,int cellNo,String number) throws IOException {
	

			   try {
					FileReader fReader = new FileReader(configFile);
					prop.load(fReader);
					fReader.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					System.out.println("FileNotFoundException");
				}
                catch (IOException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					System.out.println("IOExceptionS");
				}
			excelPath = prop.getProperty("excelpath");
			
	

		final FileInputStream file = new FileInputStream(new File(excelPath));

		XSSFWorkbook workbook = new XSSFWorkbook(file);

		XSSFSheet sheet = workbook.getSheetAt(0);
		Cell cell = null;

		// Retrieve the row and check for null
		XSSFRow sheetrow = sheet.getRow(row);
		if (sheetrow == null) {
			sheetrow = sheet.createRow(row);
			System.out.println("its null");
		}
		// Update the value of cell
		cell = sheetrow.getCell(cellNo);
		if (cell == null) {
			cell = sheetrow.createCell(cellNo);
			System.out.println("its null  2 !");
		}
        if(number!=null) {
        	cell.setCellValue(number);
        	System.out.println(number);
        	
        }
        else {
		cell.setCellValue("N");
        }
		

		file.close();
		final FileOutputStream outputStream = new FileOutputStream(excelPath);
		workbook.write(outputStream);
		System.out.println("Final Report updated successfully");

		workbook.close();
		outputStream.close();

	}
}
