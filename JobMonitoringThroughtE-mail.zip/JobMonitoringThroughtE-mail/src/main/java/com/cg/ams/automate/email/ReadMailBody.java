package com.cg.ams.automate.email;

import java.io.IOException;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
/**
*
*
* @author Sangram
*/
public class ReadMailBody {

	 // Methods to get Email message content.
	  public String getTextFromMessage(Message message) throws Exception {
	    String result = "";
	    if (message.isMimeType("text/plain")) {
	      result = message.getContent().toString();
	    } else if (message.isMimeType("multipart/*")) {
	      MimeMultipart mimeMultipart = (MimeMultipart)message.getContent();
	      System.out.println(mimeMultipart);
	      result = getTextFromMimeMultipart(mimeMultipart);
	    }
	   // result = removeHyperTextContent(result);
	    return result;
	  }

	  private String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception
	  {
	    String result = "";
	    int count = mimeMultipart.getCount();
	    for (int i = 0; i < count; i++) {
	      BodyPart bodyPart = mimeMultipart.getBodyPart(i);
	 
	      if (bodyPart.isMimeType("text/plain")) {
	        result = result + "\n" + bodyPart. getContent();
	        //System.out.println(result);
	        break; }
	      if (bodyPart.isMimeType("text/html")) {
	        String html = (String)bodyPart.getContent();
	       // System.out.println(html);
	        result = result + "\n" + html;
	      } else if ((bodyPart.getContent() instanceof MimeMultipart)) {
	        result = result + getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
	        break; //This is added to break after recursive call, otherwise it fetches the content from next MultiPart.
	      }
	    }
	    //result = removeHyperTextContent(result);
	    return result;
	  }

}
