package com.cg.ams.automate.create;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.DatatypeConverter;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class CreateIncident {
	
	private static final Logger logger = Logger.getLogger(CreateIncident.class.getName());

	static Properties prop = new Properties();
	static String inputLine;
	static String output;
	static String configFile = "D:\\Users\\sasanap\\Documents\\workspace-spring-tool-suite-4-4.15.1.RELEASE\\JobMonitoringThroughtE-mail\\src\\main\\resource\\config.properties";
    //for create incident in service now
	@POST
	@Consumes({ "application/json" })
	@Produces(MediaType.APPLICATION_JSON)
	public static void main(String[] args) throws IOException, JSONException {

		InputStream inputStream;
		String url;
		String username;
		String password;

		try {
			final FileReader fReader = new FileReader(configFile);
			prop.load(fReader);
			fReader.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("FileNotFoundException");
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("IOExceptionS");
		}
		username = prop.getProperty("username1");
		System.out.println(username);
		password = prop.getProperty("password1");
		url = prop.getProperty("snowurl");
		System.out.println(url);
        //connect to servicenow
		URL obj = new URL("https://sncapappsoneqa.service-now.com/api/now/table/incident");
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		String authString = username+":"+password;
		System.out.println("auth string: " + authString);
		String basicAuth = "Basic " + DatatypeConverter.printBase64Binary(authString.getBytes());
		con.setRequestProperty("Authorization", basicAuth);
		con.setRequestProperty("Content-Type", "application/json");

		con.setDoOutput(true);
		DataOutputStream out = new DataOutputStream(con.getOutputStream());
		out.write(getOutBytes("Testing for reusable components", "Testing for reusable components", "Poojitha Majji",
				"DAC-NAAP-UTILITIES"));

		int responseCode = con.getResponseCode();
		System.out.println("POST Response Code for Create Incident :: " + responseCode);
		logger.info("POST Response Code for Create Incident :: " + responseCode);
		 Object number = null;
		if (responseCode == 201) {
           //success code
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
				System.out.println("inputLine" + inputLine);
			}

			System.out.println(response.toString());
			String str = response.toString();
			System.out.println("Hii" + str);
        
			//for getting data from response
			JSONObject jsonObject1 = new JSONObject(response.toString());
			String incident = jsonObject1.getString("result");
			System.out.println("jsonObject1" + jsonObject1);
			JSONObject jsonObject2 = new JSONObject(incident);
			System.out.println("jsonObject2" + jsonObject2);
			 number = jsonObject2.getString("number");
			System.out.println(number + " incident");
			logger.info("Incident created:" + number);
			Object shortDescription=jsonObject2.getString("short_description");
			System.out.println(shortDescription);
			in.close();
			out.flush();
			out.close();
			con.disconnect();
		} else {

			System.out.println("POST request not worked");
			logger.info("ERROR: POST request not worked");
		}
		 String status = "Incident has been created successfully with " + number;



	}

	private static byte[] getOutBytes(String shortDesc, String desc, String callId, String asGrp) {
		JSONObject jsonObj = new JSONObject();

		try {
			jsonObj.put("short_description", shortDesc);
			jsonObj.put("description", desc);
			jsonObj.put("caller_id", callId);
			jsonObj.put("assignment_group", asGrp);

		} catch (Exception e) {
			if (e != null) {
				System.out.println("Json Exception Occured" + e.getMessage());
			}
		}
		byte[] out = jsonObj.toString().getBytes(StandardCharsets.UTF_8);
		return out;
	}
}
