package com.cg.ams.automate.initialization;

import java.io.InputStream;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class InitLogger {
	//initializing logger
		static Logger logger = null;
		//method for loading logging properties
		void loadlogs(){
		 logger = Logger.getLogger(InitLogger.class.getName());
		
		try {
			InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("logging.properties");
			LogManager.getLogManager().readConfiguration(inputStream);
			logger.info("Initializing logger");
		}catch(Exception e) {
			System.out.println("ERROR: While initializing logger");
			logger.severe("Error Message :" + e.getMessage());
			e.printStackTrace();
		}
		}
		
		
}
